var express = require('express');
const loadJsonFile = require('load-json-file');

var app = express();

var handlebars = require('express-handlebars').create({defaultLayout:'main'});
app.engine('handlebars', handlebars.engine);
app.set('view engine', 'handlebars');
app.set('port', process.env.PORT || 3000);

app.use(express.static(__dirname + '/Public'));


//************************* Routes ********************************************
app.get('/', function(reg, res){

    res.render('home');
});

app.get('/addPlayer', function(reg, res){

    res.render('addPlayer');
});

app.get('/kontakt', function(reg, res){

    res.render('kontakt');
});

app.get('/players', function(reg, res){

    res.render('players');
});

app.get('/chat', function(reg, res){

    res.render('chat');
});


var router = express.Router();

router.get('/', function(req, res) {
    res.json({ message: 'hooray! welcome to our api!' });   
});

router.get('/players', function(req, res) {

    loadJsonFile('Public/players.json').then(json => {
        if(req.query.favorites != null) {

            console.log('favorites is set to ' + req.query.favorites);
            if (req.query.favorites == 'true') {
                res.json(getFavorites(json));
            }  
            else {
                res.json({message: "Query undefined"});
            }
        }
        else if(req.query.search != null) {
            if (req.query.search.length != 1) {
                console.log('search is set to ' + req.query.search);
                res.json({message: "search value is too long"});
                return;
            }
            console.log('search is set to ' + req.query.search);
            res.json(searchPlayer(json, req.query.search));
        }
        else {
            res.json(json);
            console.log(json);
        }
    });
});

router.delete('/players/:id', function(req, res) {

    loadJsonFile('Public/players.json').then(json => {
    
        console.log(req.param.id);
        res.json({message: "Try do delete Player with id: " + req.params.id});
    });
});

router.post('/players/', function(req, res) {

    res.json({message: "Spieler wurde erfolgreich gespeichert"});
});

router.put('/players/:id', function(req, res) {

    res.json({message: "Spieler mit der ID " + req.params.id + " wurde erfolgreich geupdatet"});
});

app.use('/api', router);

//******************************************************************************

app.listen(app.get('port'), function(){

    console.log("Express startet press Ctrl-c to terminate");
});

function getFavorites(json) {

    var favJson = [];
    for (var i = 0; i < json.length; i++) {

        if (json[i].hasOwnProperty('favorit')) {

            favJson.push(json[i]);
        }
    }
    return favJson;
}

function searchPlayer(json, value) {

    var favJson = [];
    for (var i = 0; i < json.length; i++) {

        if (json[i]['name'].substring(0, 1) == value.toUpperCase()) {

            favJson.push(json[i]);
        }
    }
    return favJson;
}