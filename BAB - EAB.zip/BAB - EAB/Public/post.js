var testForm = document.getElementById('test-form');
  testForm.onsubmit = function(event) {
  
  	console.log("Test1");
      
    event.preventDefault();
    if(!checkInput())
        return;

    var formData = new FormData(testForm);

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'http://188.166.165.74:13337/api/players', true);
    xhr.responseTyp = 'json';
    xhr.onreadystatechange = function() {
        if (xhr.status != 200 && xhr.status != 304) {
            alert('HTTP error ' + xhr.status);
            return;
        }
        else {
            alert('Daten erfolgreich übermittelt');
            return;
        }
    };
    xhr.send(formData);
}