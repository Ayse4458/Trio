function isBuchstabe(value){ 
    var filter = /[^a-zA-ZäöüÄÖÜß]/ 
    if(filter.test(value)) 
        return true; 
    else 
        return false; 
} 
function isNumber(value){ 
    var filter = /[^0-9]/ 
    if(filter.test(value)) 
        return true; 
    else 
        return false; 
} 

function checkForm(form){ 
    if(isBuchstabe(form.vorname.value) || isBuchstabe(form.name.value) || isBuchstabe(form.verein.value) || isBuchstabe(form.hcoach.value) || isBuchstabe(form.acoach.value) || isNumber(form.number.value)  || isNumber(form.jahr.value) || (!document.getElementById('jaCheckBox').checked && !document.getElementById('neinCheckBox').checked) || (document.getElementById('jaCheckBox').checked && document.getElementById('neinCheckBox').checked)){ 
        alert("Einige Eingaben sind fehlerhaft. Bitte überprüfen Sie Ihre Eingaben."); 
        return false; 
    } 
 } 