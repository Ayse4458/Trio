var obj, dbParam, xmlhttp, myObj, x, txt = "";
obj = { "table":"customers", "limit":20 };
dbParam = JSON.stringify(obj);
xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        myObj = JSON.parse(this.responseText);
        txt += "<table border='1' width='100%' cellpadding='5' cellspacing='3'>" +
		"<tr>" +
		"<th>Name</th>" +
		"<th>Vorname</th>" +
		"<th>Verein</th>" +
		"<th>Coach</th>" +
		"<th>Position</th>" +
		"<th>Rückennummer</th>" +
		"<th>Geburtsjahr</th>" +
		"</tr>"
        for (x in myObj) {
            txt += "<tr><td>" + myObj[x].name + "</td>" +
			"<td>" + myObj[x].vorname + "</td>" +
			"<td>" + myObj[x].club + "</td>" +
			"<td>" + myObj[x].coach + "</td>" +
			"<td>" + myObj[x].position + "</td>" +
			"<td>" + myObj[x].number + "</td>" +
			"<td>" + myObj[x].year + "</td>" +
			"</tr>";
        }
        txt += "</table>"        
        document.getElementById("demo").innerHTML = txt;
    }
};
var url = "http://188.166.165.74:13337/api/players";
xmlhttp.open("GET", url, true);
xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xmlhttp.send("x=" + dbParam);