var obj2, dbParam2, xmlhttp2, myObj2, y, txt2 = "";
obj2 = { "table":"customers", "limit":20 };
dbParam2 = JSON.stringify(obj2);
xmlhttp2 = new XMLHttpRequest();
xmlhttp2.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        myObj2 = JSON.parse(this.responseText);
        txt2 += "<table border='1' width='100%' cellpadding='5' cellspacing='3'>" +
		"<tr>" +
		"<th>Name</th>" +
		"<th>Vorname</th>" +
		"<th>Verein</th>" +
		"<th>Coach</th>" +
		"<th>Position</th>" +
		"<th>Rückennummer</th>" +
		"<th>Geburtsjahr</th>" +
		"</tr>"
        for (y in myObj2) {
            txt2 += "<tr><td>" + myObj2[y].name + "</td>" +
			"<td>" + myObj2[y].vorname + "</td>" +
			"<td>" + myObj2[y].club + "</td>" +
			"<td>" + myObj2[y].coach + "</td>" +
			"<td>" + myObj2[y].position + "</td>" +
			"<td>" + myObj2[y].number + "</td>" +
			"<td>" + myObj2[y].year + "</td>" +
			"</tr>";
        }
        txt2 += "</table>"        
        document.getElementById("demo2").innerHTML = txt2;
    }
};
var urlx = "http://188.166.165.74:13337/api/players?favorites=true";
xmlhttp2.open("GET", urlx, true);
xmlhttp2.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xmlhttp2.send("y=" + dbParam2);